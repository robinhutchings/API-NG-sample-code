package coding.exercise.model.price;

import coding.exercise.enums.Instrument;
import coding.exercise.enums.State;

public interface TwoWayPrice {
    Instrument getInstrument();
    State getState();
    double getBidPrice();
    double getBidAmount();
    double getOfferPrice();
    double getOfferAmount();
}