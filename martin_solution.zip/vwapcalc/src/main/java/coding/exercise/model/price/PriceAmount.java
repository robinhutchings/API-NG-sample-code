package coding.exercise.model.price;

import coding.exercise.enums.Side;

public class PriceAmount {
    private final double bidPrice;
    private final double bidAmount;
    private final double offerPrice;
    private final double offerAmount;

    public PriceAmount(TwoWayPrice twoWayPrice) {
        this.bidPrice = twoWayPrice.getBidPrice();
        this.bidAmount = twoWayPrice.getBidAmount();
        this.offerPrice = twoWayPrice.getOfferPrice();
        this.offerAmount = twoWayPrice.getOfferAmount();
    }

    public double getPrice(Side side) {
        return side == Side.BID ? bidPrice : offerPrice;
    }

    public double getAmount(Side side) {
        return side == Side.BID ? bidAmount : offerAmount;
    }

    public double getPriceAmountProduct(Side side) {
        return getPrice(side) * getAmount(side);
    }
}
