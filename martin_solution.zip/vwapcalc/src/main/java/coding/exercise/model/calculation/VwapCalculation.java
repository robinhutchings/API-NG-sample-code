package coding.exercise.model.calculation;

import coding.exercise.enums.Side;

public class VwapCalculation {
    private double sumBidPriceAmountProduct;
    private double sumBidAmount;
    private double sumOfferPriceAmountProduct;
    private double sumOfferAmount;

    public double getSumPriceAmountProduct(Side side) {
        return side == Side.BID ? sumBidPriceAmountProduct : sumOfferPriceAmountProduct;
    }

    public double getSumAmount(Side side) {
        return side == Side.BID ? sumBidAmount : sumOfferAmount;
    }

    public VwapCalculation setSumPriceAmountProduct(Side side, double sumPriceAmountProduct) {
        if (side == Side.BID) {
            this.sumBidPriceAmountProduct = sumPriceAmountProduct;
        } else {
            this.sumOfferPriceAmountProduct = sumPriceAmountProduct;
        }
        return this;
    }

    public VwapCalculation setSumAmount(Side side, double sumAmount) {
        if (side == Side.BID) {
            this.sumBidAmount = sumAmount;
        } else {
            this.sumOfferAmount = sumAmount;
        }
        return this;
    }
}
