package coding.exercise.model.market;

import coding.exercise.enums.Market;
import coding.exercise.model.price.TwoWayPrice;

public interface MarketUpdate {
    Market getMarket();
    TwoWayPrice getTwoWayPrice();
}
