package coding.exercise.model.price;

import coding.exercise.enums.Instrument;
import coding.exercise.enums.State;

public final class TwoWayPriceImpl implements TwoWayPrice {
    private final Instrument instrument;
    private final State state;
    private final double bidPrice;
    private final double bidAmount;
    private final double offerPrice;
    private final double offerAmount;

    public TwoWayPriceImpl(TwoWayPriceBuilder builder) {
        this.instrument = builder.instrument;
        this.state = builder.state;
        this.bidPrice = builder.bidPrice;
        this.bidAmount = builder.bidAmount;
        this.offerPrice = builder.offerPrice;
        this.offerAmount = builder.offerAmount;
    }

    public Instrument getInstrument() {
        return instrument;
    }

    public State getState() {
        return state;
    }

    public double getBidPrice() {
        return bidPrice;
    }

    public double getBidAmount() {
        return bidAmount;
    }

    public double getOfferPrice() {
        return offerPrice;
    }

    public double getOfferAmount() {
        return offerAmount;
    }

    public static class TwoWayPriceBuilder {
        private Instrument instrument;
        private State state;
        private double bidPrice;
        private double bidAmount;
        private double offerPrice;
        private double offerAmount;

        public TwoWayPriceBuilder withInstrument(Instrument instrument) {
            this.instrument = instrument;
            return this;
        }

        public TwoWayPriceBuilder withState(State state) {
            this.state = state;
            return this;
        }

        public TwoWayPriceBuilder withBidPrice(double bidPrice) {
            this.bidPrice = bidPrice;
            return this;
        }

        public TwoWayPriceBuilder withBidAmount(double bidAmount) {
            this.bidAmount = bidAmount;
            return this;
        }

        public TwoWayPriceBuilder withOfferPrice(double offerPrice) {
            this.offerPrice = offerPrice;
            return this;
        }

        public TwoWayPriceBuilder withOfferAmount(double offerAmount) {
            this.offerAmount = offerAmount;
            return this;
        }

        public TwoWayPriceImpl build() {
            return new TwoWayPriceImpl(this);
        }
    }
}
