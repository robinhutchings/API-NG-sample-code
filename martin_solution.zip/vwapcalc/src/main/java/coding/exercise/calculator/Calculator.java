package coding.exercise.calculator;

import coding.exercise.model.market.MarketUpdate;
import coding.exercise.model.price.TwoWayPrice;

public interface Calculator {
    TwoWayPrice applyMarketUpdate(final MarketUpdate twoWayMarketPrice);
}
