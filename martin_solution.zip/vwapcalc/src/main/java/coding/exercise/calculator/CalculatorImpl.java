package coding.exercise.calculator;

import coding.exercise.enums.Instrument;
import coding.exercise.instrument.InstrumentPricer;
import coding.exercise.model.market.MarketUpdate;
import coding.exercise.model.price.TwoWayPrice;

import java.util.Map;

public class CalculatorImpl implements Calculator {
    private final Map<Instrument, InstrumentPricer> instrumentToPricer;

    public CalculatorImpl(Map<Instrument, InstrumentPricer> instrumentToPricer) {
        this.instrumentToPricer = instrumentToPricer;
    }

    public TwoWayPrice applyMarketUpdate(MarketUpdate twoWayMarketPrice) {
        TwoWayPrice newMarketPrice = twoWayMarketPrice.getTwoWayPrice();
        Instrument instrument = newMarketPrice.getInstrument();
        if (!instrumentToPricer.containsKey(instrument)) {
            instrumentToPricer.put(instrument, new InstrumentPricer(instrument));
        }
        InstrumentPricer pricer = instrumentToPricer.get(instrument);
        return pricer.getUpdatedVwapPrice(twoWayMarketPrice);
    }
}
