package coding.exercise.instrument;

import coding.exercise.enums.Instrument;
import coding.exercise.enums.Market;
import coding.exercise.enums.Side;
import coding.exercise.enums.State;
import coding.exercise.model.calculation.VwapCalculation;
import coding.exercise.model.market.MarketUpdate;
import coding.exercise.model.price.PriceAmount;
import coding.exercise.model.price.TwoWayPrice;
import coding.exercise.model.price.TwoWayPriceImpl;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

public class InstrumentPricer {
    private final Instrument instrument;
    private final Map<Market, State> marketToState;
    private final Map<Market, PriceAmount> marketToPrice;
    private final VwapCalculation vwapCalculation;

    public InstrumentPricer(Instrument instrument) {
        this.instrument = instrument;
        this.marketToState = new HashMap<>();
        this.marketToPrice = new HashMap<>();
        this.vwapCalculation = new VwapCalculation();
    }

    public TwoWayPrice getUpdatedVwapPrice(MarketUpdate marketUpdate) {
        Market market = marketUpdate.getMarket();
        TwoWayPrice twoWayPrice = marketUpdate.getTwoWayPrice();
        Optional<PriceAmount> oldMarketPrice = Optional.ofNullable(marketToPrice.get(market));
        PriceAmount newMarketPrice = new PriceAmount(twoWayPrice);
        marketToPrice.put(market, newMarketPrice);

        updateCalculations(oldMarketPrice, newMarketPrice);
        updateMarketToState(market, twoWayPrice.getState());
        return buildTwoWayPrice();
    }

    private void updateCalculations(Optional<PriceAmount> oldMarketPrice, PriceAmount newMarketPrice) {
        updateProductCalculations(Side.BID, oldMarketPrice, newMarketPrice);
        updateAmountCalculations(Side.BID, oldMarketPrice, newMarketPrice);
        updateProductCalculations(Side.OFFER, oldMarketPrice, newMarketPrice);
        updateAmountCalculations(Side.OFFER, oldMarketPrice, newMarketPrice);
    }

    private void updateAmountCalculations(Side side, Optional<PriceAmount> oldMarketPrice, PriceAmount newMarketPrice) {
        double oldAmount = oldMarketPrice.map(p -> p.getAmount(side)).orElse(0.0);
        double newAmount = newMarketPrice.getAmount(side);
        double currentSumAmount = vwapCalculation.getSumAmount(side);
        double updatedSumAmount = currentSumAmount - oldAmount + newAmount;
        vwapCalculation.setSumAmount(side, updatedSumAmount);
    }

    private void updateProductCalculations(Side side, Optional<PriceAmount> oldMarketPrice, PriceAmount newMarketPrice) {
        double oldPriceAmountProduct = oldMarketPrice.map(p -> p.getPriceAmountProduct(side)).orElse(0.0);
        double newPriceAmountProduct = newMarketPrice.getPriceAmountProduct(side);
        double currentSumPriceAmountProduct = vwapCalculation.getSumPriceAmountProduct(side);
        double updatedSumPriceAmountProduct =
                currentSumPriceAmountProduct - oldPriceAmountProduct + newPriceAmountProduct;
        vwapCalculation.setSumPriceAmountProduct(side, updatedSumPriceAmountProduct);
    }

    private void updateMarketToState(Market market, State state) {
        if (state == State.INDICATIVE) {
            marketToState.putIfAbsent(market, state);
        } else {
            marketToState.remove(market);
        }
    }

    private TwoWayPrice buildTwoWayPrice() {
        return new TwoWayPriceImpl.TwoWayPriceBuilder()
                .withInstrument(instrument)
                .withState(getOverallState())
                .withBidPrice(getVwapPrice(Side.BID))
                .withBidAmount(vwapCalculation.getSumAmount(Side.BID))
                .withOfferPrice(getVwapPrice(Side.OFFER))
                .withOfferAmount(vwapCalculation.getSumAmount(Side.OFFER))
                .build();
    }

    private double getVwapPrice(Side side) {
        return safeDivisionDefaultZero(vwapCalculation.getSumPriceAmountProduct(side),
                vwapCalculation.getSumAmount(side));
    }

    private State getOverallState() {
        return marketToState.isEmpty() ? State.FIRM : State.INDICATIVE;
    }

    private double safeDivisionDefaultZero(double num1, double num2) {
        double zero = 0.0;
        return num2 == zero ? zero : num1 / num2;
    }
}
