package coding.exercise.enums;

public enum Instrument {
    INSTRUMENT0,
    INSTRUMENT1,
    INSTRUMENT2,
    INSTRUMENT18,
    INSTRUMENT19
}