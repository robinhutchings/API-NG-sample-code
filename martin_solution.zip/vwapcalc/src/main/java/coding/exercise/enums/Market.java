package coding.exercise.enums;

public enum Market {
    MARKET0,
    MARKET1,
    MARKET2,
    MARKET48,
    MARKET49
}
