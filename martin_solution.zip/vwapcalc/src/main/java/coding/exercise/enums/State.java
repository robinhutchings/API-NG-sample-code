package coding.exercise.enums;

public enum State {
    FIRM, INDICATIVE
}