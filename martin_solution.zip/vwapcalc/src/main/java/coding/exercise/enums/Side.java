package coding.exercise.enums;

public enum Side {
    BID, OFFER
}
