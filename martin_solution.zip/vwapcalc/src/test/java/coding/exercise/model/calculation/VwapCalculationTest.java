package coding.exercise.model.calculation;

import coding.exercise.enums.Side;
import coding.exercise.testUtils.MarketPriceTestHelper;
import org.junit.Before;
import org.junit.Test;

public class VwapCalculationTest {
    private final double ZERO = 0.0;
    private final double SUM_BID_PRICE_AMOUNT_PRODUCT = 1.0;
    private final double SUM_BID_AMOUNT = 2.0;
    private final double SUM_OFFER_PRICE_AMOUNT_PRODUCT = 3.0;
    private final double SUM_OFFER_AMOUNT = 4.0;

    private VwapCalculation underTest;

    @Before
    public void setUp() {
        underTest = new VwapCalculation();
    }

    @Test
    public void testGetSetSumPriceAmountProductBid() {
        double before = underTest.getSumPriceAmountProduct(Side.BID);
        MarketPriceTestHelper.assertDoubleEquals(ZERO, before);

        underTest.setSumPriceAmountProduct(Side.BID, SUM_BID_PRICE_AMOUNT_PRODUCT);
        double after = underTest.getSumPriceAmountProduct(Side.BID);
        MarketPriceTestHelper.assertDoubleEquals(SUM_BID_PRICE_AMOUNT_PRODUCT, after);
    }

    @Test
    public void testGetSetSumPriceAmountProductOffer() {
        double before = underTest.getSumPriceAmountProduct(Side.OFFER);
        MarketPriceTestHelper.assertDoubleEquals(ZERO, before);

        underTest.setSumPriceAmountProduct(Side.OFFER, SUM_OFFER_PRICE_AMOUNT_PRODUCT);
        double after = underTest.getSumPriceAmountProduct(Side.OFFER);
        MarketPriceTestHelper.assertDoubleEquals(SUM_OFFER_PRICE_AMOUNT_PRODUCT, after);
    }

    @Test
    public void testGetSetSumAmountBid() {
        double before = underTest.getSumAmount(Side.BID);
        MarketPriceTestHelper.assertDoubleEquals(ZERO, before);

        underTest.setSumAmount(Side.BID, SUM_BID_AMOUNT);
        double after = underTest.getSumAmount(Side.BID);
        MarketPriceTestHelper.assertDoubleEquals(SUM_BID_AMOUNT, after);
    }

    @Test
    public void testGetSetSumAmountOffer() {
        double before = underTest.getSumAmount(Side.OFFER);
        MarketPriceTestHelper.assertDoubleEquals(ZERO, before);

        underTest.setSumAmount(Side.OFFER, SUM_OFFER_AMOUNT);
        double after = underTest.getSumAmount(Side.OFFER);
        MarketPriceTestHelper.assertDoubleEquals(SUM_OFFER_AMOUNT, after);
    }
}
