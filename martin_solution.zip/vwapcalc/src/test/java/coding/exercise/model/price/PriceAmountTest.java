package coding.exercise.model.price;

import coding.exercise.enums.Instrument;
import coding.exercise.enums.Side;
import coding.exercise.enums.State;
import coding.exercise.testUtils.MarketPriceTestHelper;
import org.junit.Before;
import org.junit.Test;

public class PriceAmountTest {
    private static final Instrument INSTRUMENT = Instrument.INSTRUMENT0;
    private static final State STATE = State.FIRM;
    private static final double BID_PRICE = 1.0;
    private static final double BID_AMOUNT = 2.0;
    private static final double OFFER_PRICE = 3.0;
    private static final double OFFER_AMOUNT = 4.0;

    private PriceAmount underTest;

    @Before
    public void setUp() {
        underTest = new PriceAmount(buildTwoWayPrice());
    }

    @Test
    public void testGetPriceBid() {
        double actual = underTest.getPrice(Side.BID);
        MarketPriceTestHelper.assertDoubleEquals(BID_PRICE, actual);
    }

    @Test
    public void testGetPriceOffer() {
        double actual = underTest.getPrice(Side.OFFER);
        MarketPriceTestHelper.assertDoubleEquals(OFFER_PRICE, actual);
    }

    @Test
    public void testGetAmountBid() {
        double actual = underTest.getAmount(Side.BID);
        MarketPriceTestHelper.assertDoubleEquals(BID_AMOUNT, actual);
    }

    @Test
    public void testGetAmountOffer() {
        double actual = underTest.getAmount(Side.OFFER);
        MarketPriceTestHelper.assertDoubleEquals(OFFER_AMOUNT, actual);
    }

    @Test
    public void testGetPriceAmountProductBid() {
        double actual = underTest.getPriceAmountProduct(Side.BID);
        MarketPriceTestHelper.assertDoubleEquals(BID_PRICE * BID_AMOUNT, actual);
    }

    @Test
    public void testGetPriceAmountProductOffer() {
        double actual = underTest.getPriceAmountProduct(Side.OFFER);
        MarketPriceTestHelper.assertDoubleEquals(OFFER_PRICE * OFFER_AMOUNT, actual);
    }

    private TwoWayPrice buildTwoWayPrice() {
        return new TwoWayPriceImpl.TwoWayPriceBuilder()
                .withInstrument(INSTRUMENT)
                .withState(STATE)
                .withBidPrice(BID_PRICE)
                .withBidAmount(BID_AMOUNT)
                .withOfferPrice(OFFER_PRICE)
                .withOfferAmount(OFFER_AMOUNT)
                .build();
    }
}
