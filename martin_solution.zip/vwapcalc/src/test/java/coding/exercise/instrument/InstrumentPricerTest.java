package coding.exercise.instrument;

import coding.exercise.enums.Instrument;
import coding.exercise.enums.Market;
import coding.exercise.enums.State;
import coding.exercise.model.market.MarketUpdate;
import coding.exercise.model.price.TwoWayPrice;
import coding.exercise.model.price.TwoWayPriceImpl;
import coding.exercise.testUtils.MarketPriceTestHelper;
import coding.exercise.testUtils.MarketUpdateTestHelper;
import org.junit.Before;
import org.junit.Test;

public class InstrumentPricerTest {
    private static final Instrument INSTRUMENT = Instrument.INSTRUMENT0;

    private InstrumentPricer underTest;

    @Before
    public void setUp() {
        underTest = new InstrumentPricer(INSTRUMENT);
    }

    @Test
    public void getUpdatedVwapPriceDivisionZero() {
        Market market = Market.MARKET0;
        TwoWayPrice twoWayPrice = new TwoWayPriceImpl.TwoWayPriceBuilder()
                .withInstrument(INSTRUMENT)
                .withState(State.FIRM)
                .build();
        MarketUpdate marketUpdate = MarketUpdateTestHelper.mockMarketUpdate(market, twoWayPrice);
        TwoWayPrice actual = underTest.getUpdatedVwapPrice(marketUpdate);
        MarketPriceTestHelper.assertTwoWayPrice(twoWayPrice, actual);
    }

    @Test
    public void getUpdatedVwapPriceSingle() {
        Market market = Market.MARKET0;
        TwoWayPrice twoWayPrice = new TwoWayPriceImpl.TwoWayPriceBuilder()
                .withBidPrice(2.0)
                .withBidAmount(3.0)
                .withOfferPrice(4.0)
                .withOfferAmount(5.0)
                .withInstrument(INSTRUMENT)
                .withState(State.FIRM)
                .build();
        MarketUpdate marketUpdate = MarketUpdateTestHelper.mockMarketUpdate(market, twoWayPrice);
        TwoWayPrice actual = underTest.getUpdatedVwapPrice(marketUpdate);
        MarketPriceTestHelper.assertTwoWayPrice(twoWayPrice, actual);
    }

    @Test
    public void getUpdatedVwapPriceDifferentMarkets() {
        TwoWayPrice twoWayPriceMarket1 = new TwoWayPriceImpl.TwoWayPriceBuilder()
                .withBidPrice(2.0)
                .withBidAmount(3.0)
                .withOfferPrice(4.0)
                .withOfferAmount(5.0)
                .withInstrument(INSTRUMENT)
                .withState(State.FIRM)
                .build();
        MarketUpdate marketUpdate1 = MarketUpdateTestHelper.mockMarketUpdate(Market.MARKET1, twoWayPriceMarket1);
        underTest.getUpdatedVwapPrice(marketUpdate1);

        TwoWayPrice twoWayPriceMarket2 = new TwoWayPriceImpl.TwoWayPriceBuilder()
                .withBidPrice(6.0)
                .withBidAmount(7.0)
                .withOfferPrice(8.0)
                .withOfferAmount(9.0)
                .withInstrument(INSTRUMENT)
                .withState(State.INDICATIVE)
                .build();
        MarketUpdate marketUpdate2 = MarketUpdateTestHelper.mockMarketUpdate(Market.MARKET2, twoWayPriceMarket2);
        TwoWayPrice actual = underTest.getUpdatedVwapPrice(marketUpdate2);

        TwoWayPrice expected = new TwoWayPriceImpl.TwoWayPriceBuilder()
                .withBidPrice(48.0 / 10.0)
                .withBidAmount(10.0)
                .withOfferPrice(92.0 / 14.0)
                .withOfferAmount(14.0)
                .withInstrument(INSTRUMENT)
                .withState(State.INDICATIVE)
                .build();
        MarketPriceTestHelper.assertTwoWayPrice(expected, actual);
    }

    @Test
    public void getUpdatedVwapPriceDifferentMarketsReplace() {
        TwoWayPrice twoWayPrice1Market1 = new TwoWayPriceImpl.TwoWayPriceBuilder()
                .withBidPrice(2.0)
                .withBidAmount(3.0)
                .withOfferPrice(4.0)
                .withOfferAmount(5.0)
                .withInstrument(INSTRUMENT)
                .withState(State.FIRM)
                .build();
        MarketUpdate marketUpdate1 = MarketUpdateTestHelper.mockMarketUpdate(Market.MARKET1, twoWayPrice1Market1);
        underTest.getUpdatedVwapPrice(marketUpdate1);

        TwoWayPrice twoWayPrice1Market2 = new TwoWayPriceImpl.TwoWayPriceBuilder()
                .withBidPrice(6.0)
                .withBidAmount(7.0)
                .withOfferPrice(8.0)
                .withOfferAmount(9.0)
                .withInstrument(INSTRUMENT)
                .withState(State.INDICATIVE)
                .build();
        MarketUpdate marketUpdate2 = MarketUpdateTestHelper.mockMarketUpdate(Market.MARKET2, twoWayPrice1Market2);
        underTest.getUpdatedVwapPrice(marketUpdate2);

        TwoWayPrice twoWayPrice2Market2 = new TwoWayPriceImpl.TwoWayPriceBuilder()
                .withBidPrice(11.0)
                .withBidAmount(12.0)
                .withOfferPrice(13.0)
                .withOfferAmount(14.0)
                .withInstrument(INSTRUMENT)
                .withState(State.FIRM)
                .build();
        MarketUpdate marketUpdate3 = MarketUpdateTestHelper.mockMarketUpdate(Market.MARKET2, twoWayPrice2Market2);
        TwoWayPrice actual = underTest.getUpdatedVwapPrice(marketUpdate3);

        TwoWayPrice expected = new TwoWayPriceImpl.TwoWayPriceBuilder()
                .withBidPrice(138.0 / 15.0)
                .withBidAmount(15.0)
                .withOfferPrice(202.0 / 19.0)
                .withOfferAmount(19.0)
                .withInstrument(INSTRUMENT)
                .withState(State.FIRM)
                .build();
        MarketPriceTestHelper.assertTwoWayPrice(expected, actual);
    }
}
