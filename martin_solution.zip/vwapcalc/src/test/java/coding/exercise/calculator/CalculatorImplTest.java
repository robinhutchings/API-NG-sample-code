package coding.exercise.calculator;

import coding.exercise.enums.Instrument;
import coding.exercise.enums.Market;
import coding.exercise.enums.State;
import coding.exercise.model.market.MarketUpdate;
import coding.exercise.model.price.TwoWayPrice;
import coding.exercise.model.price.TwoWayPriceImpl;
import coding.exercise.testUtils.MarketPriceTestHelper;
import coding.exercise.testUtils.MarketUpdateTestHelper;
import org.junit.Before;
import org.junit.Test;

import java.util.HashMap;

public class CalculatorImplTest {

    private CalculatorImpl underTest;

    @Before
    public void setUp() {
        underTest = new CalculatorImpl(new HashMap<>());
    }

    @Test
    public void testApplyMarketUpdateSingleInstrument() {
        Instrument instrument = Instrument.INSTRUMENT0;

        TwoWayPrice twoWayPrice1 = new TwoWayPriceImpl.TwoWayPriceBuilder()
                .withBidPrice(2.0)
                .withBidAmount(3.0)
                .withOfferPrice(4.0)
                .withOfferAmount(5.0)
                .withInstrument(instrument)
                .withState(State.FIRM)
                .build();
        MarketUpdate marketUpdate1 = MarketUpdateTestHelper.mockMarketUpdate(Market.MARKET0, twoWayPrice1);
        underTest.applyMarketUpdate(marketUpdate1);

        TwoWayPrice twoWayPrice2 = new TwoWayPriceImpl.TwoWayPriceBuilder()
                .withBidPrice(6.0)
                .withBidAmount(7.0)
                .withOfferPrice(8.0)
                .withOfferAmount(9.0)
                .withInstrument(instrument)
                .withState(State.INDICATIVE)
                .build();
        MarketUpdate marketUpdate2 = MarketUpdateTestHelper.mockMarketUpdate(Market.MARKET1, twoWayPrice2);
        underTest.applyMarketUpdate(marketUpdate2);

        TwoWayPrice twoWayPrice3 = new TwoWayPriceImpl.TwoWayPriceBuilder()
                .withBidPrice(11.0)
                .withBidAmount(12.0)
                .withOfferPrice(13.0)
                .withOfferAmount(14.0)
                .withInstrument(instrument)
                .withState(State.FIRM)
                .build();
        MarketUpdate marketUpdate3 = MarketUpdateTestHelper.mockMarketUpdate(Market.MARKET1, twoWayPrice3);
        TwoWayPrice actual = underTest.applyMarketUpdate(marketUpdate3);

        TwoWayPrice expected = new TwoWayPriceImpl.TwoWayPriceBuilder()
                .withBidPrice(138.0 / 15.0)
                .withBidAmount(15.0)
                .withOfferPrice(202.0 / 19.0)
                .withOfferAmount(19.0)
                .withInstrument(instrument)
                .withState(State.FIRM)
                .build();
        MarketPriceTestHelper.assertTwoWayPrice(expected, actual);
    }

    @Test
    public void testApplyMarketUpdateMultipleInstruments() {
        Market market = Market.MARKET0;

        TwoWayPrice twoWayPrice1Instrument1 = new TwoWayPriceImpl.TwoWayPriceBuilder()
                .withBidPrice(1.0)
                .withBidAmount(1.0)
                .withOfferPrice(1.0)
                .withOfferAmount(1.0)
                .withInstrument(Instrument.INSTRUMENT1)
                .withState(State.FIRM)
                .build();
        MarketUpdate marketUpdate1 = MarketUpdateTestHelper.mockMarketUpdate(market, twoWayPrice1Instrument1);
        underTest.applyMarketUpdate(marketUpdate1);

        TwoWayPrice twoWayPrice1Instrument2 = new TwoWayPriceImpl.TwoWayPriceBuilder()
                .withBidPrice(2.0)
                .withBidAmount(2.0)
                .withOfferPrice(2.0)
                .withOfferAmount(2.0)
                .withInstrument(Instrument.INSTRUMENT2)
                .withState(State.INDICATIVE)
                .build();
        MarketUpdate marketUpdate2 = MarketUpdateTestHelper.mockMarketUpdate(market, twoWayPrice1Instrument2);
        underTest.applyMarketUpdate(marketUpdate2);

        TwoWayPrice twoWayPrice2Instrument1 = new TwoWayPriceImpl.TwoWayPriceBuilder()
                .withBidPrice(3.0)
                .withBidAmount(3.0)
                .withOfferPrice(3.0)
                .withOfferAmount(3.0)
                .withInstrument(Instrument.INSTRUMENT1)
                .withState(State.INDICATIVE)
                .build();
        MarketUpdate marketUpdate3 = MarketUpdateTestHelper.mockMarketUpdate(market, twoWayPrice2Instrument1);
        TwoWayPrice actualPriceInstrument1 = underTest.applyMarketUpdate(marketUpdate3);
        MarketPriceTestHelper.assertTwoWayPrice(twoWayPrice2Instrument1, actualPriceInstrument1);

        TwoWayPrice twoWayPrice2Instrument2 = new TwoWayPriceImpl.TwoWayPriceBuilder()
                .withBidPrice(4.0)
                .withBidAmount(4.0)
                .withOfferPrice(4.0)
                .withOfferAmount(4.0)
                .withInstrument(Instrument.INSTRUMENT1)
                .withState(State.FIRM)
                .build();
        MarketUpdate marketUpdate4 = MarketUpdateTestHelper.mockMarketUpdate(market, twoWayPrice2Instrument2);
        TwoWayPrice actualPriceInstrument2 = underTest.applyMarketUpdate(marketUpdate4);
        MarketPriceTestHelper.assertTwoWayPrice(twoWayPrice2Instrument2, actualPriceInstrument2);
    }
}
