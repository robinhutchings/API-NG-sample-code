package coding.exercise.testUtils;

import coding.exercise.enums.Market;
import coding.exercise.model.market.MarketUpdate;
import coding.exercise.model.price.TwoWayPrice;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class MarketUpdateTestHelper {
    public static MarketUpdate mockMarketUpdate(Market market, TwoWayPrice twoWayPrice) {
        MarketUpdate marketUpdate = mock(MarketUpdate.class);
        when(marketUpdate.getMarket()).thenReturn(market);
        when(marketUpdate.getTwoWayPrice()).thenReturn(twoWayPrice);
        return marketUpdate;
    }
}
