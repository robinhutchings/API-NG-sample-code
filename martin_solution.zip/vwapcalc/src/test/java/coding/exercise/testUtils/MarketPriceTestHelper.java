package coding.exercise.testUtils;

import coding.exercise.model.price.TwoWayPrice;

import static org.junit.Assert.assertEquals;

public class MarketPriceTestHelper {
    private static final double DELTA = Math.pow(1, -10);

    public static void assertDoubleEquals(double expected, double actual) {
        assertEquals(expected, actual, DELTA);
    }

    public static void assertTwoWayPrice(TwoWayPrice expected, TwoWayPrice actual) {
        assertDoubleEquals(expected.getBidPrice(), actual.getBidPrice());
        assertDoubleEquals(expected.getBidAmount(), actual.getBidAmount());
        assertDoubleEquals(expected.getOfferPrice(), actual.getOfferPrice());
        assertDoubleEquals(expected.getOfferAmount(), actual.getOfferAmount());
        assertEquals(expected.getState(), actual.getState());
        assertEquals(expected.getInstrument(), actual.getInstrument());
    }
}
