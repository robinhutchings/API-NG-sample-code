import org.junit.Test;

import static java.lang.Double.NaN;
import static org.junit.Assert.assertEquals;

public class VWAPCaculatorTests {

    @Test
    public void testErrorUpdate() {
        final Calculator calculator = new VWAPCalculator();

        final MarketUpdate marketUpdateOne = new LiveMarketUpdate(Market.MARKET0, new LiveTwoWayPrice(Instrument.INSTRUMENT0, State.FIRM, NaN ,1000, 1.2 ,1000));
        final MarketUpdate marketUpdateTwo = new LiveMarketUpdate(Market.MARKET1, new LiveTwoWayPrice(Instrument.INSTRUMENT0, State.FIRM, 1.1 ,500, 1.3 ,500));
        final MarketUpdate marketUpdateThree = new LiveMarketUpdate(Market.MARKET1, new LiveTwoWayPrice(Instrument.INSTRUMENT0, State.FIRM, NaN ,500, 1.3 ,500));

        final TwoWayPrice vwapPriceOne = calculator.applyMarketUpdate(marketUpdateOne);
        assertEquals(null, vwapPriceOne);

        final TwoWayPrice vwapPriceTwo = calculator.applyMarketUpdate(marketUpdateTwo);
        assertEquals(1.1, vwapPriceTwo.getBidPrice(), 0.005);

        final TwoWayPrice vwapPriceThree = calculator.applyMarketUpdate(marketUpdateThree);
        assertEquals(1.1, vwapPriceThree.getBidPrice(), 0.005);

    }

    @Test
    public void testErrorUpdateZeroVolume() {
        final Calculator calculator = new VWAPCalculator();

        final MarketUpdate marketUpdateOne = new LiveMarketUpdate(Market.MARKET0, new LiveTwoWayPrice(Instrument.INSTRUMENT0, State.FIRM, 1.15 ,0, 1.2 ,1000));
        final MarketUpdate marketUpdateTwo = new LiveMarketUpdate(Market.MARKET1, new LiveTwoWayPrice(Instrument.INSTRUMENT0, State.FIRM, 1.1 ,500, 1.3 ,500));
        final MarketUpdate marketUpdateThree = new LiveMarketUpdate(Market.MARKET1, new LiveTwoWayPrice(Instrument.INSTRUMENT0, State.FIRM, 1.22 ,200, 1.3 ,0));

        final TwoWayPrice vwapPriceOne = calculator.applyMarketUpdate(marketUpdateOne);
        assertEquals(null, vwapPriceOne);

        final TwoWayPrice vwapPriceTwo = calculator.applyMarketUpdate(marketUpdateTwo);
        assertEquals(1.1, vwapPriceTwo.getBidPrice(), 0.005);

        final TwoWayPrice vwapPriceThree = calculator.applyMarketUpdate(marketUpdateThree);
        assertEquals(1.1, vwapPriceThree.getBidPrice(), 0.005);

    }

    @Test
    public void testVwapCalculation() {
        final Calculator calculator = new VWAPCalculator();

        final MarketUpdate marketUpdateOne = new LiveMarketUpdate(Market.MARKET0, new LiveTwoWayPrice(Instrument.INSTRUMENT0, State.FIRM, 1 ,1000, 1.2 ,1000));
        final MarketUpdate marketUpdateTwo = new LiveMarketUpdate(Market.MARKET1, new LiveTwoWayPrice(Instrument.INSTRUMENT0, State.FIRM, 1.1 ,500, 1.3 ,500));

        final TwoWayPrice vwapPriceOne = calculator.applyMarketUpdate(marketUpdateOne);
        assertEquals(1.0, vwapPriceOne.getBidPrice(), 0.005);
        assertEquals(1.2, vwapPriceOne.getOfferPrice(), 0.005);


        final TwoWayPrice vwapPriceTwo = calculator.applyMarketUpdate(marketUpdateTwo);
        assertEquals(0.9, vwapPriceTwo.getBidPrice(), 0.005);
        assertEquals(1.1, vwapPriceTwo.getOfferPrice(), 0.005);
    }

    @Test
    public void testVwapUpdatedPriceCalculation() {
        final Calculator calculator = new VWAPCalculator();

        final MarketUpdate marketUpdateOne = new LiveMarketUpdate(Market.MARKET0, new LiveTwoWayPrice(Instrument.INSTRUMENT0, State.FIRM, 1.523 ,1000, 1.724 ,1000));
        final MarketUpdate marketUpdateTwo = new LiveMarketUpdate(Market.MARKET0, new LiveTwoWayPrice(Instrument.INSTRUMENT0, State.FIRM, 1.1 ,500, 1.3 ,500));

        final TwoWayPrice vwapPriceOne = calculator.applyMarketUpdate(marketUpdateOne);
        assertEquals(1.52, vwapPriceOne.getBidPrice(), 0.005);
        assertEquals(1.72, vwapPriceOne.getOfferPrice(), 0.005);

        final TwoWayPrice vwapPriceTwo = calculator.applyMarketUpdate(marketUpdateTwo);
        assertEquals(1.1, vwapPriceTwo.getBidPrice(), 0.005);
        assertEquals(1.3, vwapPriceTwo.getOfferPrice(), 0.005);
    }

    @Test
    public void testStateUpdatesCorrectly() {
        final Calculator calculator = new VWAPCalculator();

        final MarketUpdate marketUpdateOne = new LiveMarketUpdate(Market.MARKET0, new LiveTwoWayPrice(Instrument.INSTRUMENT0, State.FIRM, 1 ,1000, 1.2 ,1000));
        final MarketUpdate marketUpdateTwo = new LiveMarketUpdate(Market.MARKET1, new LiveTwoWayPrice(Instrument.INSTRUMENT0, State.FIRM, 1.1 ,500, 1.3 ,500));
        final MarketUpdate marketUpdateThree = new LiveMarketUpdate(Market.MARKET2, new LiveTwoWayPrice(Instrument.INSTRUMENT0, State.INDICATIVE, 1.02 ,200, 1.22 ,200));
        final MarketUpdate marketUpdateFour = new LiveMarketUpdate(Market.MARKET1, new LiveTwoWayPrice(Instrument.INSTRUMENT0, State.FIRM, 1.05 ,2000, 1.25 ,2000));
        final MarketUpdate marketUpdateFive = new LiveMarketUpdate(Market.MARKET2, new LiveTwoWayPrice(Instrument.INSTRUMENT0, State.FIRM, 1.05 ,2000, 1.25 ,2000));

        final TwoWayPrice vwapPriceOne = calculator.applyMarketUpdate(marketUpdateOne);
        assertEquals(vwapPriceOne.getState(), State.FIRM);

        final TwoWayPrice vwapPriceTwo = calculator.applyMarketUpdate(marketUpdateTwo);
        assertEquals(vwapPriceTwo.getState(), State.FIRM);

        final TwoWayPrice vwapPriceThree = calculator.applyMarketUpdate(marketUpdateThree);
        assertEquals(vwapPriceThree.getState(), State.INDICATIVE);

        final TwoWayPrice vwapPriceFour = calculator.applyMarketUpdate(marketUpdateFour);
        assertEquals(vwapPriceFour.getState(), State.INDICATIVE);

        final TwoWayPrice vwapPriceFive = calculator.applyMarketUpdate(marketUpdateFive);
        assertEquals(vwapPriceFive.getState(), State.FIRM);
    }
}
