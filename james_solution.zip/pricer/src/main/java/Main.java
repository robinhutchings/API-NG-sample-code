public class Main {
    public static void main(String[] args) {
        System.out.println("Please run JUnit tests to test the functionality of the application");
    }
}