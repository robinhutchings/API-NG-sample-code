public class LiveMarketUpdate implements MarketUpdate {

    private final Market market;
    private final TwoWayPrice twoWayPrice;

    public LiveMarketUpdate(final Market market, final TwoWayPrice twoWayPrice) {
        this.market = market;
        this.twoWayPrice = twoWayPrice;
    }

    public Market getMarket() {
        return this.market;
    }

    public TwoWayPrice getTwoWayPrice() {
        return this.twoWayPrice;
    }
}
