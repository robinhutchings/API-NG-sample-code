public enum Side {
    BID,
    OFFER
}
