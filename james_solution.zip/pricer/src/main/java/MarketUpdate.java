public interface MarketUpdate {
    Market getMarket();
    TwoWayPrice getTwoWayPrice();
}
