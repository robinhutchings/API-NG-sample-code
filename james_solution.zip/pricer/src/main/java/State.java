public enum State {
    FIRM,
    INDICATIVE
}
