import java.util.*;
import org.apache.log4j.Logger;

public class VWAPCalculator implements Calculator {

    private final static Logger logger = Logger.getLogger(VWAPCalculator.class.getName());

    private final Map<Instrument, VwapCalculation> latestPrices = new HashMap<Instrument, VwapCalculation>();

    public TwoWayPrice applyMarketUpdate(MarketUpdate twoWayMarketPrice) {

        final Market market = twoWayMarketPrice.getMarket();
        final TwoWayPrice newTwoWayPrice = twoWayMarketPrice.getTwoWayPrice();
        final Instrument instrument = newTwoWayPrice.getInstrument();
        final State state = newTwoWayPrice.getState();

        logger.info("Update received from " + market + " for " + instrument + ". Ignoring update.");

        final TwoWayPrice vwap;
        if (latestPrices.containsKey(instrument)) {
            final VwapCalculation calculation = latestPrices.get(instrument);

            if (validateUpdate(newTwoWayPrice)) {
                calculation.updatePrice(market, newTwoWayPrice);
            } else {
                logger.warn("Received update with NaN or zero values from " + market + " for " + instrument + ". Ignoring update.");
            }

            vwap = calculation.getResult();
        } else {
            if (validateUpdate(newTwoWayPrice)) {
                final VwapCalculation calculation = new VwapCalculation(instrument, market, newTwoWayPrice);
                vwap = calculation.getResult();
                latestPrices.put(instrument, calculation);
            } else {
                logger.warn("Received update with NaN or zero values from " + market + " for " + instrument + ". Ignoring update.");
                return null;
            }
        }

        logger.info("Latest VWAP for: " + instrument + " is: " + String.format("%.2f", vwap.getBidPrice()) + " / " + String.format("%.2f", vwap.getOfferPrice()) + " (" + vwap.getState() + ")");

        return vwap;
    }

    private boolean validateUpdate(TwoWayPrice twoWayPrice) {
        return !(
                Double.isNaN(twoWayPrice.getBidPrice()) ||
                Double.isNaN(twoWayPrice.getBidAmount()) ||
                twoWayPrice.getBidAmount() == 0.0 ||
                Double.isNaN(twoWayPrice.getOfferPrice()) ||
                twoWayPrice.getOfferAmount() == 0 ||
                Double.isNaN(twoWayPrice.getOfferAmount())
                );
    }

    private class VwapCalculation {
        private Instrument instrument;
        private double cumulativeBidPriceByVolume;
        private double cumulativeBidVolume;
        private double cumulativeOfferPriceByVolume;
        private double cumulativeOfferVolume;
        private Map<Market, TwoWayPrice> latestPerMarket = new HashMap<Market, TwoWayPrice>();
        private int indicativeCount = 0;

        private VwapCalculation(Instrument instrument, Market market, TwoWayPrice twoWayPrice) {
            this.instrument = instrument;
            this.cumulativeBidPriceByVolume = twoWayPrice.getBidPrice() * twoWayPrice.getBidAmount();
            this.cumulativeBidVolume = twoWayPrice.getBidAmount();
            this.cumulativeOfferPriceByVolume = twoWayPrice.getOfferPrice() * twoWayPrice.getOfferAmount();
            this.cumulativeOfferVolume = twoWayPrice.getOfferAmount();
            this.latestPerMarket.put(market, twoWayPrice);
            if (twoWayPrice.getState() == State.INDICATIVE) {
                indicativeCount += 1;
            }
        }

        private void updatePrice(Market market, TwoWayPrice newTwoWayPrice) {
            if (this.latestPerMarket.containsKey(market)) {
                final TwoWayPrice oldTwoWayPrice = this.latestPerMarket.get(market);
                this.cumulativeBidPriceByVolume -= oldTwoWayPrice.getBidPrice() * oldTwoWayPrice.getBidAmount();
                this.cumulativeBidVolume -= oldTwoWayPrice.getBidAmount();
                this.cumulativeOfferPriceByVolume -= oldTwoWayPrice.getOfferPrice() * oldTwoWayPrice.getOfferAmount();
                this.cumulativeOfferVolume -= oldTwoWayPrice.getOfferAmount();
                if (oldTwoWayPrice.getState() == State.INDICATIVE) {
                    this.indicativeCount -= 1;
                }
            }

            this.latestPerMarket.put(market, newTwoWayPrice);

            this.cumulativeBidPriceByVolume -= newTwoWayPrice.getBidPrice() * newTwoWayPrice.getBidAmount();
            this.cumulativeBidVolume -= newTwoWayPrice.getBidAmount();
            this.cumulativeOfferPriceByVolume -= newTwoWayPrice.getOfferPrice() * newTwoWayPrice.getOfferAmount();
            this.cumulativeOfferVolume -= newTwoWayPrice.getOfferAmount();

            if (newTwoWayPrice.getState() == State.INDICATIVE) {
                this.indicativeCount += 1;
            }
        }

        private TwoWayPrice getResult() {

            final double bidPrice = this.cumulativeBidPriceByVolume / this.cumulativeBidVolume;
            final double offerPrice = this.cumulativeOfferPriceByVolume / this.cumulativeOfferVolume;

            int numberOfPrices = latestPerMarket.size();
            return new LiveTwoWayPrice(this.instrument, this.indicativeCount > 0 ? State.INDICATIVE : State.FIRM, bidPrice, this.cumulativeBidVolume / numberOfPrices, offerPrice, this.cumulativeOfferVolume / numberOfPrices);
        }
    }
}
